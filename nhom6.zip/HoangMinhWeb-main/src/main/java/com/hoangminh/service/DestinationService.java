package com.hoangminh.service;

public interface DestinationService {

}
