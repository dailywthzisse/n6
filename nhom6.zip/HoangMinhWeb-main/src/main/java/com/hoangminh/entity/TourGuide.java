package com.hoangminh.entity;

public class TourGuide {
	
}
