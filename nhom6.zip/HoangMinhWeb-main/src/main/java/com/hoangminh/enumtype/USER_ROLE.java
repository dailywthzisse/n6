package com.hoangminh.enumtype;

public enum USER_ROLE {
	USER,
	ADMIN,
	MANAGER
}
