package com.hoangminh.repository;

public interface DestinationRepository {

}
